import re
import sys

f = open("C:\\Users\shyan\Desktop\CS 330 Structure and Organization\Midterm\ALevel.java", "r")
text = ""
for line in f:
    text = text + line + " "
f.close()


# remove imports
def imports():
    pattern = (r'(\s+import\s{1,}(\w+\.\n*\s*)+([\w\*]+)(\;{1}))')
    mo = re.findall(pattern, text)
    if mo:
        mo.clear()
        print("Imports parsed/removed")
        print(mo)
        print("\n")
    else:
        print("Error with import statement(s)")
        sys.exit()


# remove single-line comments
def singleLine():
    pattern = (r'(\s+\/{2,}.*\s+)')
    mo = re.findall(pattern, text)
    if mo:
        mo.clear()
        print("Single-line comments parsed/removed")
        print(mo)
        print("\n")
    else:
        print("Error with single-line comment")
        sys.exit()


# remove multi-line comments
def multiLine():
    pattern = (r'(\s*\/{1}\*{1,}\s*.*\s*.*\s*\*{1,}\/{1,}\s+)')
    mo = re.findall(pattern, text)
    if mo:
        mo.clear()
        print("Multi-line comments parsed/removed")
        print(mo)
        print("\n")
    else:
        print("Error with multi-line comment")
        sys.exit()


# print main class body with braces
def mainClassBody():
    pattern = (
        r'(\W\s+class\s+\w+\{{1}\s+(public\s+static\s+void\s+main\s*\({1}String\s*\[{1}\]{1}\s+args\){1}\{{1}\s+){1}((.|\n)*)(\s+\}{1}\s+\}{1}\s+\W){1})')
    mo = re.findall(pattern, text)
    if mo:
        print("Main class parsed\n")
    else:
        print("Syntax error in main class declaration and/or braces\n")
        sys.exit()


# print class declaration
def classDecl():
    pattern = (r'(\s+class\s+[A-Z]+\w*\{\W\s+)')
    mo = re.findall(pattern, text)
    if mo:
        print("Class declarations:")
        mo2 = "".join(mo)
        print(re.sub(r'(\n)', ' ', mo2))
        print("\n")
    elif re.error(mo, text):
        print("Syntax error in class declaration\n")
        sys.exit()


# public static void main
def publicStatic():
    pattern = (r'(\s+public\s{1,}static\s{1,}void\s{1,}main\s*\({1}String\s{1,}\[{1}\s*\]{1}\s*args\){1}\{\n+\s*)')
    mo = re.findall(pattern, text)
    if mo:
        print("Public static void main method parsed:")
        mo2 = "".join(mo)
        print(re.sub(r'(\n)', ' ', mo2))
        print("\n")
    else:
        print("Syntax error in public static void main")
        sys.exit()


# print class body with braces
def classBody():
    pattern = (
        r'(class\s{1,}([A-Z]\w*)\s*\{{1}\n+\s+(int\s+\w+\;{1}\n*\s*)*(String\s+\w+\;{1}\n*\s*)*(((public|private|protected)*\s+[A-Z]\w+\({1}int\s+[a-z]+\,{1}\s*String\s+[a-z]+\){1}\{{1}\n*\s*)([a-z]+\s*\={1}\s*[a-z]{1}\;{1}\s+)*\}{1}\s+){1}((public|private|protected)\s+void*\s+\w+\({1}\){1}\{{1}\n*\s*)((.|\n)*\s+\}{1}\s+\}{1}))')
    mo = re.findall(pattern, text)
    if mo:
        print("Class body parsed\n")
    else:
        print("Syntax error in class body declaration/braces")
        sys.exit()


# prints system.out.println statements
def printState():
    pattern = (r'(\s+System\.{1}out\.{1}println\({1}\"{1}.*\"{1}\){1}\;{1}\s+)')
    mo = re.findall(pattern, text)
    if mo:
        print("Print statements:")
        print("\n".join(mo))
    else:
        print("Syntax error in print statement")
        sys.exit()


# print expressions
def expressions():
    pattern = (r'(\s+[a-z]+\s*\={1}\s*[a-z]+\s*\+{1}\s*\d\;{1}\s+)')
    mo = re.findall(pattern, text)
    if mo:
        print("Expressions:")
        print("\n".join(mo))
    else:
        print("Syntax error in expression")
        sys.exit()


# print scanner
def scanner():
    pattern = (r'(Scanner\s{1,}\w+\s*\={1}\s*new\s{1,}Scanner\({1}System\.in\){1}\;{1}\n*\s*)')
    mo = re.findall(pattern, text)
    if mo:
        print("Scanner declaration:")
        mo2 = "".join(mo)
        print(re.sub(r'(\n)', ' ', mo2))
        print("\n")
    else:
        print("Syntax error in scanner declaration")
        sys.exit()


# print scanner inputs
def scannerInput():
    pattern = (r'((String|int)\s+\w+\s*\={1}\s*sc\.{1}next(|Int)\({1}\){1}\;{1})')
    mo = re.findall(pattern, text)
    if mo:
        print("Scanner input(s) parsed:")
        print(mo)
        print("\n")
    else:
        print("Syntax error in scanner input")
        sys.exit()


# print int variable declaration
def intVar():
    pattern = (r'(int\s{1,}[a-z]+[A-Z]*\w*\s*\={1}\s*\d\;{1})')
    mo = re.findall(pattern, text)
    if mo:
        print("int variable declaration:")
        print(mo)
        print("\n")
    else:
        print("Syntax error in int declaration")
        sys.exit()


# print String variable declaration
def stringVar():
    pattern = (r'(String\s{1,}[a-z]+[A-Z]*\w*\s*\={1}\s*\"{1}.*\"{1}\;{1})')
    mo = re.findall(pattern, text)
    if mo:
        print("String variable declaration:")
        print(mo)
        print("\n")
    else:
        print("Syntax error in String declaration")
        sys.exit()


# print boolean declaration
def boolDec():
    pattern = (r'(boolean\s{1,}[a-z]+\w*\s*\={1}\s*(true|false)\;{1})')
    mo = re.findall(pattern, text)
    if mo:
        print("boolean variable declaration:")
        print(mo)
        print("\n")
    else:
        print("Syntax error in boolean declaration")
        sys.exit()


# print if statement
def ifState():
    pattern = (
        r'(if\s*\({1}\w+\s*((<|>)|(<=|>=)|(==|!=))\s*\d+\){1}\{{1}\n*\s+System\.{1}out\.{1}println\({1}\"{1}.*\"{1}\){1}\;{1}\n*\s*\}\n*\s*)')
    mo = re.findall(pattern, text)
    if mo:
        print("if statement(s) parsed:")
        print(mo)
        print("\n")
    else:
        print("Syntax error in if statement")
        sys.exit()


# print else statement
def elseState():
    pattern = (r'(else\{{1}\n*\s*System\.{1}out\.{1}println\({1}\"{1}.*\"{1}\){1}\;{1}\n*\s*\}{1}\n*\s*)')
    mo = re.findall(pattern, text)
    if mo:
        print("else statement(s) parsed")
        print(mo)
        print("\n")
    else:
        print("Syntax error in else statement")
        sys.exit()


# print while statement
def whileLoop():
    pattern = (
        r'(while\({1}\w+\s*(<|>)\=*\s*\d+\){1}\{{1}\n*\s*System\.{1}out\.{1}println\({1}\"{1}.*\"{1}\s*\+\s*\w+\){1}\;{1}\n*\s*[a-z]+\s*\={1}\s*[a-z]+\s*\+{1}\s*\d\;{1}\n*\s*\}{1}\n*\s*)')
    mo = re.findall(pattern, text)
    if mo:
        print("while loop(s) parsed:")
        print(mo)
        print("\n")
    else:
        print("Syntax error in while condition")
        sys.exit()


# print class object delaration
def objDecl():
    pattern = (r'([A-Z]\w*\s+[a-z]+\s*\={1}\s*new\s+[A-Z]\w*\({1}\w*\,*\s*\w*\){1}\;{1}\n*\s*)')
    mo = re.findall(pattern, text)
    if mo:
        print("Class object declaration parsed:")
        mo2 = "".join(mo)
        print(re.sub(r'(/(\r\n)+|\r+|\n+|\t+/i)', ' ', mo2))
        print("\n")
    else:
        print("Syntax error in object declaration")
        sys.exit()


# print class func call
def functCall():
    pattern = (r'(\n\s+[a-z]+\.{1}\w+\({1}\){1}\;{1}\n*\s*)')
    mo = re.findall(pattern, text)
    if mo:
        print("Class function call parsed:")
        mo2 = "".join(mo)
        print(re.sub(r'(\n)', ' ', mo2))
        print("\n")
    else:
        print("Syntax error in class function call")
        sys.exit()


# print person instance int variable
def instVar():
    pattern = (r'(\s+(public|private|protected){0,1}\s+int\s*\w+\;{1}\n*\s*)')
    mo = re.findall(pattern, text)
    if mo:
        print("Int instance variable parsed:")
        print(mo)
        print("\n")
    else:
        print("Syntax error in int instance")
        sys.exit()


# print person instance string variable
def instString():
    pattern = (r'(\s+(public|private|protected){0,1}\s+String\s*\w+\;{1}\n*\s*)')
    mo = re.findall(pattern, text)
    if mo:
        print("String instance variable parsed:")
        print(mo)
        print("\n")
    else:
        print("Syntax error in int instance")
        sys.exit()


# print class decl with parameters
def classDeclPar():
    pattern = (r'((public|private|protected)\s+[A-Z]\w+\({1}int\s+[a-z]+\,{1}\s*String\s+[a-z]+\){1}\{{1}\n*\s*)')
    mo = re.findall(pattern, text)
    if mo:
        print("Class decl with parameters parsed:")
        print(mo)
        print("\n")
    else:
        print("Syntax error in class declaration")
        sys.exit()


# print constructor variables
def constructVar():
    pattern = (r'([a-z]+\s*\={1}\s*[a-z]{1}\;{1})')
    mo = re.findall(pattern, text)
    if mo:
        print("Constructor variables parsed:")
        print(mo)
        print("\n")
    else:
        print("Syntax error in class constructor")
        sys.exit()


# print class function
def classFunc():
    pattern = (r'((public|private|protected)\s+void*\s+\w+\({1}\){1}\{{1}\n*\s*)')
    mo = re.findall(pattern, text)
    if mo:
        print("Class function parsed:")
        print(mo)
        print("\n")
    else:
        print("Syntax error in class function")
        sys.exit()


# print printInfo func string concat
def printInfo():
    pattern = (
        r'(System\.{1}out\.{1}println\({1}\"{1}.*\"{1}\s*\+{1}\s*\w+\s*\+{1}\s*\"{1}.*\"{1}\s*\+{1}\s*\w+\s*\+{1}\s*\"{1}.*\"{1}\){1}\;{1}\n*\s*)')
    mo = re.findall(pattern, text)
    if mo:
        print("String concatenation parsed:")
        print(mo)
        print("\n")
    else:
        print("Syntax error in string concatenation")
        sys.exit()
