import func_lib as scl

def main():
    f = open("C:\\Users\shyan\Desktop\CS 330 Structure and Organization\Midterm\ALevel.java", "r")
    text = ""
    for line in f:
        text = text + line + " "
    f.close()

    # Remove
    scl.multiLine()
    scl.imports()
    scl.singleLine()

    # Class body/declaration
    scl.mainClassBody()
    scl.classBody()
    scl.classDecl()

    # Main class
    scl.publicStatic()
    scl.scanner()
    scl.printState()
    scl.scannerInput()
    scl.intVar()
    scl.stringVar()
    scl.boolDec()
    scl.expressions()
    scl.ifState()
    scl.elseState()
    scl.whileLoop()
    scl.objDecl()
    scl.functCall()

    # Second class
    scl.classDeclPar()
    scl.instVar()
    scl.instString()
    scl.constructVar()
    scl.classFunc()
    scl.printInfo()


main()